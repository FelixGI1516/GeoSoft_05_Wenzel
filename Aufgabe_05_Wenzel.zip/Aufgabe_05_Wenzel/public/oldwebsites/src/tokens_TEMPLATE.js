//to use this, insert your api key as a string, and remove the "_TEMPLATE" from
// the file name. KEEP YOUR KEYS SECRET.

const HERE_API_KEY = ...;
const HERE_APP_ID = ...;