/**
 * @desc Funktion shows an simple alert.
 */
function showAlert(){
    alert("Button Clicked")
}